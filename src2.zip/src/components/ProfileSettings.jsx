﻿function ProfileSettings({
    currentUser,
    profileData,
    onChange,
    onImageChange,
    onSave
}) {
    if (!currentUser) return null

    return (
        <div className="section">
            <h3>الإعدادات / الملف الشخصي</h3>

            <div className="form-grid">
                <input
                    type="text"
                    name="name"
                    placeholder="الاسم"
                    value={profileData.name}
                    onChange={onChange}
                />

                <input
                    type="text"
                    value={currentUser.phone}
                    disabled
                />

                <input
                    type="text"
                    value={currentUser.village}
                    disabled
                />

                <input type="file" accept="image/*" onChange={onImageChange} />
            </div>

            <div className="form-actions">
                <button className="primary-btn" onClick={onSave}>
                    حفظ التعديلات
                </button>
            </div>

            <p className="message error">
                لا يمكن تغيير رقم الهاتف أو القرية بعد التسجيل
            </p>
        </div>
    )
}

export default ProfileSettings