import { useEffect, useMemo, useState } from 'react'
import './App.css'

import { loadEvents, saveEvents } from './services/eventService'
import {
    loadUsers,
    saveUsers,
    registerUser,
    loginWithPassword,
    loginWithOtp,
    updateUserProfile
} from './services/userService'
import { loadValue, saveValue, STORAGE_KEYS } from './services/storageService'

import { Event } from './models/Event'
import {
    canAddEvent,
    canDeleteEvent,
    canEditEvent,
    canViewEvent,
    canApproveEvent,
    canRejectEvent,
    getNewEventStatus
} from './utils/permissions'
import { sortEvents, filterEvents, validateEventForm } from './utils/eventUtils'

import VillageSelector from './components/VillageSelector'
import SearchBox from './components/SearchBox'
import AddEventForm from './components/AddEventForm'
import ShowEvent from './components/ShowEvent'
import AuthPanel from './components/AuthPanel'

function App() {
    // ---------------- USERS ----------------
    const [usersData, setUsersData] = useState(loadUsers())

    const [currentUserId, setCurrentUserId] = useState(
        loadValue(STORAGE_KEYS.currentUserId, null)
    )

    const currentUser = useMemo(
        () => usersData.find((user) => user.id === currentUserId) || null,
        [usersData, currentUserId]
    )

    // ---------------- AUTH STATE ----------------
    const [registerData, setRegisterData] = useState({
        name: '',
        phone: '',
        password: '',
        village: '',
        profileImage: ''
    })

    const [loginData, setLoginData] = useState({
        phone: '',
        password: ''
    })

    const [otpPhone, setOtpPhone] = useState('')

    const [registerError, setRegisterError] = useState('')
    const [registerSuccess, setRegisterSuccess] = useState('')

    const [loginError, setLoginError] = useState('')
    const [loginSuccess, setLoginSuccess] = useState('')

    const [otpError, setOtpError] = useState('')
    const [otpSuccess, setOtpSuccess] = useState('')

    const [profileData, setProfileData] = useState({
        name: '',
        profileImage: ''
    })

    // ---------------- APP STATE ----------------
    const [selectedVillage, setSelectedVillage] = useState(
        loadValue(STORAGE_KEYS.selectedVillage, '')
    )

    const [search, setSearch] = useState(
        loadValue(STORAGE_KEYS.searchText, '')
    )

    const [eventsData, setEventsData] = useState(loadEvents())

    const [editingEventId, setEditingEventId] = useState(null)

    const [formData, setFormData] = useState({
        groom: '',
        bride: '',
        hall: '',
        date: ''
    })

    const [errorMessage, setErrorMessage] = useState('')
    const [successMessage, setSuccessMessage] = useState('')

    // ---------------- EFFECTS ----------------
    useEffect(() => {
        saveUsers(usersData)
    }, [usersData])

    useEffect(() => {
        saveEvents(eventsData)
    }, [eventsData])

    useEffect(() => {
        saveValue(STORAGE_KEYS.currentUserId, currentUserId)
    }, [currentUserId])

    useEffect(() => {
        saveValue(STORAGE_KEYS.selectedVillage, selectedVillage)
    }, [selectedVillage])

    useEffect(() => {
        saveValue(STORAGE_KEYS.searchText, search)
    }, [search])

    useEffect(() => {
        if (currentUser) {
            setProfileData({
                name: currentUser.name,
                profileImage: currentUser.profileImage || ''
            })

            setSelectedVillage(currentUser.village || '')
        }
    }, [currentUser])

    // ---------------- HELPERS ----------------
    function resetForm() {
        setFormData({
            groom: '',
            bride: '',
            hall: '',
            date: ''
        })
        setEditingEventId(null)
    }

    function clearMessages() {
        setErrorMessage('')
        setSuccessMessage('')
    }

    // ---------------- AUTH HANDLERS ----------------
    function handleRegisterChange(event) {
        const { name, value } = event.target

        setRegisterData((prev) => ({
            ...prev,
            [name]: value
        }))
    }

    function handleRegisterImageChange(event) {
        const file = event.target.files?.[0]
        if (!file) return

        const fakeImagePath = file.name

        setRegisterData((prev) => ({
            ...prev,
            profileImage: fakeImagePath
        }))
    }

    function handleRegisterSubmit() {
        setRegisterError('')
        setRegisterSuccess('')

        if (
            !registerData.name.trim() ||
            !registerData.phone.trim() ||
            !registerData.password.trim() ||
            !registerData.village
        ) {
            setRegisterError('يرجى تعبئة جميع حقول التسجيل المطلوبة')
            return
        }

        const result = registerUser(usersData, registerData)

        if (!result.success) {
            setRegisterError(result.message)
            return
        }

        setUsersData(result.users)

        // ❌ הסר או הער את השורה הזו
        // setCurrentUserId(result.user.id)
        setRegisterSuccess('تم إنشاء الحساب بنجاح — يمكنك تسجيل الدخول الآن')
       

        setRegisterData({
            name: '',
            phone: '',
            password: '',
            village: '',
            profileImage: ''
        })
    }

    function handleLoginChange(event) {
        const { name, value } = event.target

        setLoginData((prev) => ({
            ...prev,
            [name]: value
        }))
    }

    function handleLoginSubmit() {
        setLoginError('')
        setLoginSuccess('')

        const result = loginWithPassword(usersData, loginData.phone, loginData.password)

        if (!result.success) {
            setLoginError(result.message)
            return
        }

        setCurrentUserId(result.user.id)
        setLoginSuccess('تم تسجيل الدخول بنجاح')

        setLoginData({
            phone: '',
            password: ''
        })
    }

    function handleOtpSubmit() {
        setOtpError('')
        setOtpSuccess('')

        const result = loginWithOtp(usersData, otpPhone)

        if (!result.success) {
            setOtpError(result.message)
            return
        }

        setCurrentUserId(result.user.id)
        setOtpSuccess(result.message)
        setOtpPhone('')
    }

    function handleProfileChange(event) {
        const { name, value } = event.target

        setProfileData((prev) => ({
            ...prev,
            [name]: value
        }))
    }

    function handleProfileImageChange(event) {
        const file = event.target.files?.[0]
        if (!file) return

        setProfileData((prev) => ({
            ...prev,
            profileImage: file.name
        }))
    }

    function handleProfileSave() {
        if (!currentUser) return

        const updatedUsers = updateUserProfile(usersData, currentUser.id, profileData)
        setUsersData(updatedUsers)
        setSuccessMessage('تم حفظ بيانات الملف الشخصي')
        setErrorMessage('')
    }

    // ---------------- APP HANDLERS ----------------
    function handleVillageChange(event) {
        const value = event.target.value
        setSelectedVillage(value)
        setSearch('')
        clearMessages()
        resetForm()
    }

    function handleSearchChange(event) {
        setSearch(event.target.value)
        setSuccessMessage('')
    }

    function handleClearSearch() {
        setSearch('')
    }

    function handleFormChange(event) {
        const { name, value } = event.target

        setFormData((prev) => ({
            ...prev,
            [name]: value
        }))

        setSuccessMessage('')
    }

    function handleEditEvent(eventItem) {
        if (!canEditEvent(currentUser, eventItem)) {
            setErrorMessage('ليس لديك صلاحية تعديل هذا العرس')
            setSuccessMessage('')
            return
        }

        setFormData({
            groom: eventItem.groom,
            bride: eventItem.bride,
            hall: eventItem.hall,
            date: eventItem.date
        })

        setEditingEventId(eventItem.id)
        setErrorMessage('')
        setSuccessMessage('')
    }

    function handleDeleteEvent(eventId) {
        const targetEvent = eventsData.find((item) => item.id === eventId)
        if (!targetEvent) return

        if (!canDeleteEvent(currentUser, targetEvent)) {
            setErrorMessage('ليس لديك صلاحية حذف هذا العرس')
            setSuccessMessage('')
            return
        }

        const confirmDelete = window.confirm('هل أنت متأكد من حذف هذا العرس؟')
        if (!confirmDelete) return

        const updatedEvents = eventsData.filter((item) => item.id !== eventId)
        setEventsData(updatedEvents)

        const updatedUsers = usersData.map((user) => ({
            ...user,
            myEvents: user.myEvents.filter((id) => id !== eventId)
        }))
        setUsersData(updatedUsers)

        setSuccessMessage('تم حذف العرس بنجاح')
        setErrorMessage('')

        if (editingEventId === eventId) {
            resetForm()
        }
    }

    function handleApproveEvent(eventId) {
        const targetEvent = eventsData.find((item) => item.id === eventId)
        if (!targetEvent) return

        if (!canApproveEvent(currentUser, targetEvent)) {
            setErrorMessage('ليس لديك صلاحية الموافقة على هذا العرس')
            setSuccessMessage('')
            return
        }

        const updatedEvents = eventsData.map((item) =>
            item.id === eventId ? { ...item, status: 'approved' } : item
        )

        setEventsData(updatedEvents)
        setSuccessMessage('تمت الموافقة على العرس')
        setErrorMessage('')
    }

    function handleRejectEvent(eventId) {
        const targetEvent = eventsData.find((item) => item.id === eventId)
        if (!targetEvent) return

        if (!canRejectEvent(currentUser, targetEvent)) {
            setErrorMessage('ليس لديك صلاحية رفض هذا العرس')
            setSuccessMessage('')
            return
        }

        const updatedEvents = eventsData.map((item) =>
            item.id === eventId ? { ...item, status: 'rejected' } : item
        )

        setEventsData(updatedEvents)
        setSuccessMessage('تم رفض العرس')
        setErrorMessage('')
    }

    function handleLogout() {
        setCurrentUserId(null)

        setLoginSuccess('')
        setRegisterSuccess('')
        setOtpSuccess('')

        setErrorMessage('')
        setSuccessMessage('')
    }

    function handleSubmitEvent() {
        clearMessages()

        if (!canAddEvent(currentUser, selectedVillage)) {
            setErrorMessage('ليس لديك صلاحية إضافة عرس في هذه القرية')
            return
        }

        const validationMessage = validateEventForm(formData, selectedVillage, currentUser)
        if (validationMessage) {
            setErrorMessage(validationMessage)
            return
        }

        const payload = {
            groom: formData.groom.trim(),
            bride: formData.bride.trim(),
            hall: formData.hall.trim(),
            date: formData.date,
            village: selectedVillage,
            title: `${formData.groom.trim()} / ${formData.bride.trim()}`
        }

        if (editingEventId) {
            const originalEvent = eventsData.find((item) => item.id === editingEventId)

            if (!originalEvent) {
                setErrorMessage('لم يتم العثور على العرس المطلوب تعديله')
                return
            }

            if (!canEditEvent(currentUser, originalEvent)) {
                setErrorMessage('ليس لديك صلاحية تعديل هذا العرس')
                return
            }

            const updatedEvents = eventsData.map((item) =>
                item.id === editingEventId ? { ...item, ...payload } : item
            )

            setEventsData(updatedEvents)
            setSuccessMessage('تم تحديث العرس بنجاح')
            resetForm()
            return
        }

        const status = getNewEventStatus(currentUser, selectedVillage)

        const newEvent = Event.create({
            ...payload,
            createdByUserId: currentUser.id,
            status
        }).toJSON()

        setEventsData((prev) => [...prev, newEvent])

        const updatedUsers = usersData.map((user) =>
            user.id === currentUser.id
                ? {
                    ...user,
                    myEvents: [...user.myEvents, newEvent.id]
                }
                : user
        )
        setUsersData(updatedUsers)

        if (status === 'pending') {
            setSuccessMessage('تم إرسال العرس بانتظار الموافقة')
        } else {
            setSuccessMessage('تمت إضافة العرس بنجاح')
        }

        resetForm()
    }

    // ---------------- DERIVED ----------------
    const visibleEvents = useMemo(() => {
        return eventsData.filter(
            (eventItem) =>
                eventItem.village === selectedVillage &&
                canViewEvent(currentUser, eventItem)
        )
    }, [eventsData, selectedVillage, currentUser])

    const filteredEvents = useMemo(() => {
        return filterEvents(visibleEvents, search)
    }, [visibleEvents, search])

    const sortedEvents = useMemo(() => {
        return sortEvents(filteredEvents)
    }, [filteredEvents])

    // ---------------- UI ----------------
    return (
        <div className="app-shell">
            <div className="app-card">
                <h1>DEWEDDING</h1>
                <p className="subtitle">إدارة الأعراس قبل Firebase</p>
                {currentUser && (
                    <button className="secondary-btn" onClick={handleLogout}>
                        تسجيل الخروج
                    </button>
                )}
                <div style={{ marginTop: '10px' }}>
                    <select
                        value={currentUserId || ''}
                        onChange={(e) => setCurrentUserId(Number(e.target.value))}
                    >
                        <option value="">اختيار مستخدم للاختبار</option>

                        {usersData.map((user) => (
                            <option key={user.id} value={user.id}>
                                {user.name} - {user.role}
                            </option>
                        ))}
                    </select>
                </div>
                <AuthPanel
                    currentUser={currentUser}
                    registerData={registerData}
                    onRegisterChange={handleRegisterChange}
                    onRegisterImageChange={handleRegisterImageChange}
                    onRegisterSubmit={handleRegisterSubmit}
                    registerError={registerError}
                    registerSuccess={registerSuccess}
                    loginData={loginData}
                    onLoginChange={handleLoginChange}
                    onLoginSubmit={handleLoginSubmit}
                    loginError={loginError}
                    loginSuccess={loginSuccess}
                    otpPhone={otpPhone}
                    onOtpPhoneChange={(e) => setOtpPhone(e.target.value)}
                    onOtpSubmit={handleOtpSubmit}
                    otpError={otpError}
                    otpSuccess={otpSuccess}
                    profileData={profileData}
                    onProfileChange={handleProfileChange}
                    onProfileImageChange={handleProfileImageChange}
                    onProfileSave={handleProfileSave}
                />

                {currentUser && (
                    <>
                        <VillageSelector
                            selectedVillage={selectedVillage}
                            onVillageChange={handleVillageChange}
                        />

                        {selectedVillage && visibleEvents.length > 0 && (
                            <SearchBox
                                search={search}
                                onSearchChange={handleSearchChange}
                                onClearSearch={handleClearSearch}
                            />
                        )}

                        {selectedVillage && (
                            <AddEventForm
                                formData={formData}
                                onFormChange={handleFormChange}
                                onSubmit={handleSubmitEvent}
                                onCancelEdit={resetForm}
                                errorMessage={errorMessage}
                                successMessage={successMessage}
                                editingEventId={editingEventId}
                                canAddEvent={canAddEvent(currentUser, selectedVillage)}
                            />
                        )}

                        <ShowEvent
                            selectedVillage={selectedVillage}
                            sortedEvents={sortedEvents}
                            currentUser={currentUser}
                            onEditEvent={handleEditEvent}
                            onDeleteEvent={handleDeleteEvent}
                            onApproveEvent={handleApproveEvent}
                            onRejectEvent={handleRejectEvent}
                        />
                    </>
                )}
            </div>
        </div>
    )
}

export default App