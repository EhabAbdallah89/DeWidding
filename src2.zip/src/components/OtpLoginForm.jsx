﻿function OtpLoginForm({
    otpPhone,
    onChange,
    onSubmit,
    errorMessage,
    successMessage
}) {
    return (
        <div className="section">
            <h3>دخول تجريبي عبر OTP</h3>

            <div className="form-grid">
                <input
                    type="text"
                    placeholder="رقم الهاتف"
                    value={otpPhone}
                    onChange={onChange}
                />
            </div>

            <div className="form-actions">
                <button className="secondary-btn" onClick={onSubmit}>
                    دخول OTP
                </button>
            </div>

            {errorMessage && <p className="message error">{errorMessage}</p>}
            {successMessage && <p className="message success">{successMessage}</p>}
        </div>
    )
}

export default OtpLoginForm