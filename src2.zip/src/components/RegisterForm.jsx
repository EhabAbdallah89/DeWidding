﻿import { villages } from '../data/seedData'

function RegisterForm({
    registerData,
    onChange,
    onImageChange,
    onSubmit,
    errorMessage,
    successMessage
}) {
    return (
        <div className="section">
            <h3>تسجيل حساب جديد</h3>

            <div className="form-grid">
                <input
                    type="text"
                    name="name"
                    placeholder="الاسم الكامل"
                    value={registerData.name}
                    onChange={onChange}
                />

                <input
                    type="text"
                    name="phone"
                    placeholder="رقم الهاتف"
                    value={registerData.phone}
                    onChange={onChange}
                />

                <input
                    type="password"
                    name="password"
                    placeholder="كلمة المرور"
                    value={registerData.password}
                    onChange={onChange}
                />

                <select
                    name="village"
                    value={registerData.village}
                    onChange={onChange}
                >
                    <option value="">اختر القرية</option>
                    {villages.map((village) => (
                        <option key={village} value={village}>
                            {village}
                        </option>
                    ))}
                </select>

                <input type="file" accept="image/*" onChange={onImageChange} />
            </div>

            <p className="message error">
                ملاحظة: لا يمكن تغيير القرية أو رقم الهاتف لاحقًا
            </p>

            <div className="form-actions">
                <button className="primary-btn" onClick={onSubmit}>
                    تسجيل
                </button>
            </div>

            {errorMessage && <p className="message error">{errorMessage}</p>}
            {successMessage && <p className="message success">{successMessage}</p>}
        </div>
    )
}

export default RegisterForm