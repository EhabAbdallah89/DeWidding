﻿import RegisterForm from './RegisterForm'
import LoginForm from './LoginForm'
import OtpLoginForm from './OtpLoginForm'
import ProfileSettings from './ProfileSettings'

function AuthPanel(props) {
    const {
        currentUser,
        registerData,
        onRegisterChange,
        onRegisterImageChange,
        onRegisterSubmit,
        registerError,
        registerSuccess,
        loginData,
        onLoginChange,
        onLoginSubmit,
        loginError,
        loginSuccess,
        otpPhone,
        onOtpPhoneChange,
        onOtpSubmit,
        otpError,
        otpSuccess,
        profileData,
        onProfileChange,
        onProfileImageChange,
        onProfileSave
    } = props

    return (
        <div className="section">
            {!currentUser ? (
                <>
                    <RegisterForm
                        registerData={registerData}
                        onChange={onRegisterChange}
                        onImageChange={onRegisterImageChange}
                        onSubmit={onRegisterSubmit}
                        errorMessage={registerError}
                        successMessage={registerSuccess}
                    />

                    <LoginForm
                        loginData={loginData}
                        onChange={onLoginChange}
                        onSubmit={onLoginSubmit}
                        errorMessage={loginError}
                        successMessage={loginSuccess}
                    />

                    <OtpLoginForm
                        otpPhone={otpPhone}
                        onChange={onOtpPhoneChange}
                        onSubmit={onOtpSubmit}
                        errorMessage={otpError}
                        successMessage={otpSuccess}
                    />
                </>
            ) : (
                <ProfileSettings
                    currentUser={currentUser}
                    profileData={profileData}
                    onChange={onProfileChange}
                    onImageChange={onProfileImageChange}
                    onSave={onProfileSave}
                />
            )}
        </div>
    )
}

export default AuthPanel