﻿function LoginForm({
    loginData,
    onChange,
    onSubmit,
    errorMessage,
    successMessage
}) {
    return (
        <div className="section">
            <h3>تسجيل الدخول بكلمة المرور</h3>

            <div className="form-grid">
                <input
                    type="text"
                    name="phone"
                    placeholder="رقم الهاتف"
                    value={loginData.phone}
                    onChange={onChange}
                />

                <input
                    type="password"
                    name="password"
                    placeholder="كلمة المرور"
                    value={loginData.password}
                    onChange={onChange}
                />
            </div>

            <div className="form-actions">
                <button className="primary-btn" onClick={onSubmit}>
                    دخول
                </button>
            </div>

            {errorMessage && <p className="message error">{errorMessage}</p>}
            {successMessage && <p className="message success">{successMessage}</p>}
        </div>
    )
}

export default LoginForm